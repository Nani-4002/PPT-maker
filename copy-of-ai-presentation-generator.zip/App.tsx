
import React, { useState, useCallback } from 'react';
import { ConfigPanel } from './components/ConfigPanel';
import { PresentationViewer } from './components/PresentationViewer';
import { LoadingSpinner } from './components/LoadingSpinner';
import { generatePresentationContent, generateImage } from './services/geminiService';
import type { Slide, SlideContent, Theme } from './types';
import { THEMES } from './constants';
import { WandSparklesIcon } from './components/icons';

const App: React.FC = () => {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [selectedTheme, setSelectedTheme] = useState<Theme>(THEMES[0]);

  const handleGenerate = useCallback(async (topic: string, numSlides: number) => {
    setIsLoading(true);
    setError(null);
    setSlides([]);

    try {
      setLoadingMessage(`Generating content for ${numSlides} slides on "${topic}"...`);
      const slideContents: SlideContent[] = await generatePresentationContent(topic, numSlides);
      
      const slidesWithImages: Slide[] = await Promise.all(
        slideContents.map(async (content, index) => {
          setLoadingMessage(`Generating image for slide ${index + 1}/${numSlides}...`);
          const imageUrl = await generateImage(content.imagePrompt);
          return {
            title: content.title,
            content: content.content,
            imageUrl: imageUrl,
          };
        })
      );

      setSlides(slidesWithImages);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred. Check the console for details.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, []);

  return (
    <div className={`flex flex-col md:flex-row h-screen font-sans ${selectedTheme.background}`}>
      <ConfigPanel
        onGenerate={handleGenerate}
        isLoading={isLoading}
        themes={THEMES}
        selectedTheme={selectedTheme}
        onThemeChange={setSelectedTheme}
      />
      <main className="flex-1 flex flex-col items-center justify-center p-4 md:p-8 overflow-hidden transition-colors duration-500">
        {isLoading ? (
          <div className="text-center">
            <LoadingSpinner />
            <p className={`mt-4 text-lg ${selectedTheme.textColor}`}>{loadingMessage}</p>
          </div>
        ) : error ? (
          <div className="text-center text-red-500 bg-red-100 p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-2">Generation Failed</h2>
            <p>{error}</p>
          </div>
        ) : slides.length > 0 ? (
          <PresentationViewer slides={slides} theme={selectedTheme} />
        ) : (
          <div className={`text-center ${selectedTheme.textColor}`}>
             <WandSparklesIcon className="mx-auto h-24 w-24 text-slate-400" />
            <h1 className={`mt-4 text-3xl font-bold tracking-tight ${selectedTheme.titleColor}`}>AI Presentation Generator</h1>
            <p className="mt-2 text-lg">
              Fill in the details on the left and let AI craft your presentation.
            </p>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
