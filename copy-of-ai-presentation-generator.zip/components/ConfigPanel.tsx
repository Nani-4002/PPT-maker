import React, { useState } from 'react';
import type { Theme } from '../types';
import { ThemeSelector } from './ThemeSelector';
import { WandSparklesIcon } from './icons';

interface ConfigPanelProps {
  onGenerate: (topic: string, numSlides: number) => void;
  isLoading: boolean;
  themes: Theme[];
  selectedTheme: Theme;
  onThemeChange: (theme: Theme) => void;
}

export const ConfigPanel: React.FC<ConfigPanelProps> = ({ onGenerate, isLoading, themes, selectedTheme, onThemeChange }) => {
  const [topic, setTopic] = useState<string>('The Future of Renewable Energy');
  const [numSlides, setNumSlides] = useState<number>(5);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim()) {
      onGenerate(topic, numSlides);
    }
  };

  const accentColorClass = selectedTheme.accentColor.replace('bg-', 'accent-');
  const ringOffsetClass = selectedTheme.isDark ? 'focus:ring-offset-slate-900' : 'focus:ring-offset-white';
  
  const inputBgClass = selectedTheme.isDark ? 'bg-white/10' : 'bg-black/5';
  const rangeBgClass = selectedTheme.isDark ? 'bg-white/20' : 'bg-black/10';
  const placeholderClass = selectedTheme.isDark ? 'placeholder-slate-400' : 'placeholder-slate-500';

  return (
    <aside className={`w-full md:w-96 ${selectedTheme.sidebarBg} p-6 md:p-8 ${selectedTheme.sidebarTextColor} shadow-2xl md:h-screen md:overflow-y-auto border-r ${selectedTheme.sidebarBorderColor} transition-colors duration-500`}>
      <div className="flex items-center mb-8">
        <div className={`p-2 rounded-lg mr-4 ${selectedTheme.accentColor}`}>
          <WandSparklesIcon className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight">PPT.ai</h1>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="topic" className={`block text-sm font-medium ${selectedTheme.sidebarSubtleTextColor}`}>
            Presentation Topic
          </label>
          <div className="mt-1">
            <input
              type="text"
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., The History of Space Exploration"
              className={`w-full ${inputBgClass} border ${selectedTheme.sidebarInputBorderColor} rounded-md shadow-sm py-2 px-3 ${placeholderClass} focus:outline-none focus:ring-2 ${selectedTheme.sidebarRingColor}`}
              required
            />
          </div>
        </div>

        <div>
          <label htmlFor="num-slides" className={`block text-sm font-medium ${selectedTheme.sidebarSubtleTextColor}`}>
            Number of Slides: <span className={`font-bold ${selectedTheme.sidebarTextColor}`}>{numSlides}</span>
          </label>
          <div className="mt-2">
            <input
              type="range"
              id="num-slides"
              min="3"
              max="25"
              value={numSlides}
              onChange={(e) => setNumSlides(parseInt(e.target.value))}
              className={`w-full h-2 ${rangeBgClass} rounded-lg appearance-none cursor-pointer ${accentColorClass}`}
            />
             <div className={`flex justify-between text-xs ${selectedTheme.sidebarSubtleTextColor} mt-1`}>
                <span>3</span>
                <span>25</span>
            </div>
          </div>
        </div>

        <div>
          <label className={`block text-sm font-medium ${selectedTheme.sidebarSubtleTextColor} mb-2`}>
            Theme
          </label>
          <ThemeSelector themes={themes} selectedTheme={selectedTheme} onSelect={onThemeChange} />
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className={`w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${selectedTheme.accentColor} hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 ${ringOffsetClass} ${selectedTheme.sidebarRingColor} disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300`}
        >
          {isLoading ? 'Generating...' : 'Create Presentation'}
           {!isLoading && <WandSparklesIcon className="ml-2 h-5 w-5" />}
        </button>
      </form>
    </aside>
  );
};