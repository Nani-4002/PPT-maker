import React, { useState, useEffect } from 'react';
import PptxGenJS from 'pptxgenjs';
import type { Slide, Theme } from '../types';
import { SingleSlide } from './Slide';
import { ArrowLeftIcon, ArrowRightIcon, DownloadIcon, SpinnerIcon } from './icons';

interface PresentationViewerProps {
  slides: Slide[];
  theme: Theme;
}

export const PresentationViewer: React.FC<PresentationViewerProps> = ({ slides, theme }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [animationClass, setAnimationClass] = useState('animate-fade-in');
  const [isDownloading, setIsDownloading] = useState(false);

  useEffect(() => {
    setCurrentSlide(0);
  }, [slides]);

  const goToNextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setAnimationClass('animate-slide-in-right');
      setTimeout(() => setCurrentSlide(currentSlide + 1), 0);
    }
  };

  const goToPrevSlide = () => {
    if (currentSlide > 0) {
      setAnimationClass('animate-slide-in-left');
      setTimeout(() => setCurrentSlide(currentSlide - 1), 0);
    }
  };
  
  useEffect(() => {
    // Reset animation class after it plays
    const timer = setTimeout(() => setAnimationClass('animate-fade-in'), 500);
    return () => clearTimeout(timer);
  }, [currentSlide]);

  const handleDownload = async () => {
    if (!slides.length) return;
    setIsDownloading(true);
    try {
      const pptx = new PptxGenJS();
      pptx.layout = 'LAYOUT_16x9';

      for (const slide of slides) {
        const pptxSlide = pptx.addSlide();
        pptxSlide.background = { color: theme.slideBgHex };

        pptxSlide.addText(slide.title, {
            x: 0.5, y: 0.25, w: '90%', h: 1,
            fontSize: 32,
            bold: true,
            color: theme.titleColorHex,
        });

        pptxSlide.addText(slide.content.join('\n'), {
            x: 0.5, y: 1.5, w: 4.5, h: 3.75,
            fontSize: 14,
            color: theme.textColorHex,
            bullet: true,
            paraSpaceAfter: 8,
        });
        
        const imageOptions: PptxGenJS.ImageProps = { x: 5.5, y: 1.5, w: 4, h: 2.25 };
        if (slide.imageUrl.startsWith('data:image')) {
            imageOptions.data = slide.imageUrl;
        } else {
            imageOptions.path = slide.imageUrl;
        }
        pptxSlide.addImage(imageOptions);
      }

      const fileName = slides[0]?.title.replace(/[^a-z0-9]/gi, '_').toLowerCase() || 'presentation';
      await pptx.writeFile({ fileName: `${fileName}.pptx` });

    } catch (error) {
        console.error("Failed to generate PPTX:", error);
    } finally {
        setIsDownloading(false);
    }
  };

  if (!slides.length) return null;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center">
      <div className={`w-full max-w-4xl aspect-[16/9] ${animationClass}`}>
        <SingleSlide slide={slides[currentSlide]} theme={theme} />
      </div>
      <div className="mt-6 flex items-center justify-between w-full max-w-4xl">
        <button
          onClick={goToPrevSlide}
          disabled={currentSlide === 0}
          className={`p-2 rounded-full transition-colors ${theme.slideBg} ${theme.textColor} disabled:opacity-30 disabled:cursor-not-allowed hover:bg-opacity-80`}
          aria-label="Previous Slide"
        >
          <ArrowLeftIcon className="h-6 w-6" />
        </button>

        <div className="flex items-center space-x-4">
            <span className={`${theme.textColor} text-sm font-medium`}>
            Slide {currentSlide + 1} of {slides.length}
            </span>
            <button
                onClick={handleDownload}
                disabled={isDownloading}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full transition-colors text-xs font-semibold ${theme.slideBg} ${theme.textColor} hover:bg-opacity-80 border ${theme.isDark ? 'border-white/20' : 'border-black/20'} disabled:opacity-70 disabled:cursor-wait`}
                aria-label="Download Presentation"
            >
                {isDownloading ? (
                    <>
                    <SpinnerIcon className="h-4 w-4" />
                    <span>Generating...</span>
                    </>
                ) : (
                    <>
                    <DownloadIcon className="h-4 w-4" />
                    <span>Download PPTX</span>
                    </>
                )}
            </button>
        </div>
        
        <button
          onClick={goToNextSlide}
          disabled={currentSlide === slides.length - 1}
          className={`p-2 rounded-full transition-colors ${theme.slideBg} ${theme.textColor} disabled:opacity-30 disabled:cursor-not-allowed hover:bg-opacity-80`}
          aria-label="Next Slide"
        >
          <ArrowRightIcon className="h-6 w-6" />
        </button>
      </div>
    </div>
  );
};