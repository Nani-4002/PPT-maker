import React from 'react';
import type { Slide, Theme } from '../types';

interface SingleSlideProps {
  slide: Slide;
  theme: Theme;
}

export const SingleSlide: React.FC<SingleSlideProps> = ({ slide, theme }) => {
  return (
    <div className={`w-full h-full ${theme.slideBg} shadow-2xl rounded-lg flex overflow-hidden p-8 transition-colors duration-500`}>
      <div className="flex-[2] flex flex-col pr-8 overflow-y-auto">
        <h2 className={`text-4xl font-bold ${theme.titleColor} mb-6 flex-shrink-0`}>{slide.title}</h2>
        <ul className="space-y-3">
          {slide.content.map((point, index) => (
            <li key={index} className={`flex items-start ${theme.textColor} text-lg`}>
              <span className={`mr-3 mt-2 w-2.5 h-2.5 ${theme.accentColor} rounded-full flex-shrink-0`}></span>
              <span>{point}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="flex-1 flex items-center justify-center">
        {slide.imageUrl ? (
          <img
            src={slide.imageUrl}
            alt={slide.title}
            className="object-cover w-full h-full rounded-md shadow-lg"
          />
        ) : (
          <div className="w-full h-full bg-gray-200 rounded-md flex items-center justify-center">
            <span className="text-gray-400">Image loading...</span>
          </div>
        )}
      </div>
    </div>
  );
};