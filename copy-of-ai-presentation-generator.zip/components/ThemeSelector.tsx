
import React from 'react';
import type { Theme } from '../types';

interface ThemeSelectorProps {
  themes: Theme[];
  selectedTheme: Theme;
  onSelect: (theme: Theme) => void;
}

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({ themes, selectedTheme, onSelect }) => {
  const hoverBorderClass = selectedTheme.isDark ? 'hover:border-white/50' : 'hover:border-slate-400/50';

  return (
    <div className="grid grid-cols-2 gap-3">
      {themes.map((theme) => (
        <button
          key={theme.name}
          type="button"
          onClick={() => onSelect(theme)}
          className={`p-2 rounded-lg border-2 transition-all duration-200 ${
            selectedTheme.name === theme.name ? theme.accentBorderColor : `border-transparent ${hoverBorderClass}`
          }`}
        >
          <div className="flex items-center space-x-2">
            <div className={`w-10 h-10 rounded ${theme.slideBg} flex items-center justify-center p-1`}>
                <div className={`w-full h-2/3 ${theme.accentColor} rounded-sm`}></div>
            </div>
            <span className="text-sm font-medium text-left">{theme.name}</span>
          </div>
        </button>
      ))}
    </div>
  );
};
