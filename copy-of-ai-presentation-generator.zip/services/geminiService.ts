import { GoogleGenAI, Type } from '@google/genai';
import type { SlideContent } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const contentGenerationModel = 'gemini-2.5-flash';
const imageGenerationModel = 'imagen-3.0-generate-002';

const slideSchema = {
  type: Type.OBJECT,
  properties: {
    title: {
      type: Type.STRING,
      description: 'A short, engaging title for the slide. Should be 5-10 words.',
    },
    content: {
      type: Type.ARRAY,
      description: 'An array of 4 to 6 detailed bullet points for the slide content. Each bullet point should be a comprehensive string.',
      items: { type: Type.STRING },
    },
    imagePrompt: {
      type: Type.STRING,
      description: "A descriptive, detailed prompt (10-20 words) for an AI image generator to create a visually appealing and relevant image for this slide. Be creative and suggest different styles like 'photorealistic 3D render', 'abstract watercolor', 'minimalist vector art', or 'dramatic cinematic photo'. Focus on concepts, not text. Example: 'A vibrant digital illustration of a neural network with glowing nodes and connections.'",
    },
  },
  required: ['title', 'content', 'imagePrompt'],
};

export async function generatePresentationContent(topic: string, numSlides: number): Promise<SlideContent[]> {
  const prompt = `
    You are an expert presentation creator. Your task is to generate the content for a ${numSlides}-slide presentation on the topic: "${topic}".
    Provide substantial, detailed information for each slide.
    Your output MUST be a valid JSON array. Do not include any introductory text or markdown formatting like \`\`\`json.
    The first slide should be a title slide and the last should be a summary or 'Thank You' slide.
    Generate exactly ${numSlides} objects in the array. Ensure the content flows logically from one slide to the next, creating a coherent presentation.
  `;

  try {
    const response = await ai.models.generateContent({
      model: contentGenerationModel,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: slideSchema,
        },
      },
    });

    const jsonText = response.text.trim();
    const parsedContent = JSON.parse(jsonText);
    
    if (!Array.isArray(parsedContent)) {
        throw new Error("API did not return a valid array of slide content.");
    }
    
    return parsedContent as SlideContent[];

  } catch (error) {
    console.error('Error generating presentation content:', error);
    throw new Error('Failed to generate presentation content from AI. Please check your prompt or API key.');
  }
}

// Array of visual styles to add variety to generated images.
const imageStyles = [
    "Professional photorealistic image",
    "Cinematic, dramatic lighting",
    "Minimalist vector illustration",
    "Abstract watercolor painting",
    "Detailed 3D render",
    "Vibrant digital art illustration",
    "Futuristic concept art",
    "Macro photography shot",
];

export async function generateImage(prompt: string): Promise<string> {
    try {
        // Prepend a random style to the prompt to ensure visual diversity.
        const randomStyle = imageStyles[Math.floor(Math.random() * imageStyles.length)];
        const enhancedPrompt = `${randomStyle} for a presentation slide about: ${prompt}. No text in the image, clean and modern aesthetic.`;

        const response = await ai.models.generateImages({
            model: imageGenerationModel,
            prompt: enhancedPrompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '16:9',
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes = response.generatedImages[0].image.imageBytes;
            return `data:image/jpeg;base64,${base64ImageBytes}`;
        } else {
            throw new Error('No image was generated.');
        }

    } catch (error) {
        console.error('Error generating image:', error);
        // Return a placeholder or throw an error
        return 'https://picsum.photos/1600/900';
    }
}