export interface Slide {
  title: string;
  content: string[];
  imageUrl: string;
}

export interface SlideContent {
    title: string;
    content: string[];
    imagePrompt: string;
}

export interface Theme {
  name: string;
  background: string;
  titleColor: string;
  textColor: string;
  accentColor: string;
  accentBorderColor: string;
  slideBg: string;
  sidebarBg: string;
  sidebarTextColor: string;
  sidebarSubtleTextColor: string;
  sidebarInputBorderColor: string;
  sidebarRingColor: string;
  sidebarBorderColor: string;
  isDark: boolean;
  titleColorHex: string;
  textColorHex: string;
  slideBgHex: string;
}